# Xray IBM Cloud部署

## 提示：

1：用的人增多，肯定会步达拉斯的后尘，用起来别太狠，建议轻度用户使用

2：脚本默认情况下：仅支持IBM伦敦，每天自动更新Xray并重启

3：切换区域到英国伦敦：ibmcloud target -r eu-gb

   | Secrets变量 | 形式 |
  | --------------------- | ----------- |
  | `IBM_CF_USERNAME`       | IBM Cloud 邮箱地址 |
  | `IBM_CF_PASSWORD` | IBM Cloud 邮箱密码 |
  | `IBM_CF_APP_NAME` | IBM Cloud 应用程序名 |
  | `XRAY_UUID` | 自定义UUID码 |
  | `XRAY_WS_PATH_VMESS` </br> `XRAY_WS_PATH_VLESS` | 协议选择一个，填入自定义PATH路径 |
  
注：VMESS默认的alterId为 8

> 本项目基于[P3TERX项目](https://github.com/P3TERX/IBM-CF-V2)修改适配Xray而来，默认安装最新版本Xray，感谢P3TERX
